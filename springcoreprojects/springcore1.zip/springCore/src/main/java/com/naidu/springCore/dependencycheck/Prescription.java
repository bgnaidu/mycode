package com.naidu.springCore.dependencycheck;

import java.util.List;

public class Prescription {

	private int id;
	private String patienceName;
	private List<String> medicines;

	public List<String> getMedicines() {
		return medicines;
	}

	public void setMedicines(List<String> medicines) {
		this.medicines = medicines;
	}

	public String getPatienceName() {
		return patienceName;
	}

	public void setPatienceName(String patienceName) {
		this.patienceName = patienceName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}
